const fs = require('fs');

const html = fs.readFileSync('Mission Architect_ Space Base.html', 'utf8');
const scriptRegex = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
let match;
let scriptIndex = 0;
while ((match = scriptRegex.exec(html)) !== null) {
   scriptIndex++;
   const code = match[1];
   console.log(`Checking script ${scriptIndex}, length ${code.length}`);
   try {
      new Function(code);
      console.log(`Script ${scriptIndex}: Syntax OK`);
   } catch (err) {
      console.error(`Script ${scriptIndex} Syntax Error:`, err.message);
   }
}
