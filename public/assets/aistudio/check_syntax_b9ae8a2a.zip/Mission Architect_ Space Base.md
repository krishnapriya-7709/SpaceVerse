# SPACEVERSE: GALAXY-X Space Research Facility

Welcome to **SPACEVERSE**, an interactive aerospace mission engineering simulation developed inside an advanced NASA-inspired research complex operated by **GALAXY-X**.

---

## 1. Opening Experience & Recruitment

- **SPACEVERSE Title Screen:** Futuristic, space-themed glowing typography with an automated 2.6-second loading sequence.
- **Interactive Welcome Sequence:**
  - 4 Progressive messages displayed in a teletype / typewriter style with a blinking cyan cursor (`▌`).
  - Animated 3D background showcasing active facility operations (telemetry waveforms, rotating holograms, moving gantry crane hoist, and test spacecraft).
  - Clicking **ACCEPT INVITATION ★** issues the **GALAXY-X New Recruit Badge**, awards starting resources (**10,000 Grant Credits** and **100 Star Credits**), and initiates Cadet Training.

---

## 2. Interactive Cadet Training Phase (Mandatory Before Levels & Replayable Anytime)

New cadets are introduced to the facility through 6 physical, hands-on tasks across the complex before commanding independent missions.

### Training Introduction
- **Header:** `CADET TRAINING INITIATED`
- **Briefing:** *"Welcome aboard, Explorer! Before you begin your missions, let's get familiar with your new workspace. Explore the facility, interact with its equipment, and learn how space missions come together."*
- **Actions:**
  - Click **BEGIN TRAINING** to start the hands-on guided tutorial.
  - Click **SKIP TUTORIAL ❯** to bypass training and immediately access the 10-level campaign.
  - Players can click the **Skip ✕** button on the training HUD at any point.
  - **Always Accessible:** Cadet Training can be started, resumed, or replayed at any time via the **`🎓 Cadet Training`** button on the Top Command Bar or the featured banner in the Level Chart.

### Video Game-Style Tutorial Mechanics
- **Visual Waypoint Beacons:** Floating, animated glowing 3D beacons indicate exact targets.
- **Spotlight Highlights:** Active UI buttons and map sectors pulse with a high-visibility cyan border.
- **Direct 3D Raycasting & Key Interaction:** Click objects directly in the 3D world with the mouse or walk up and press <kbd>E</kbd>.
- **Live Progress Indicator:** Flight Academy HUD widget at the top-center displaying `TRAINING PROGRESS: X/6` with an animated segmented progress bar and checklist guidance.
- **Clean HUD Architecture:** Unrelated telemetry boxes (such as Rocket Manifest) are automatically hidden during training to keep the interface clean and immersive.
- **Explanatory Dialogs:** Every completed task provides an educational breakdown with a **CONTINUE** button.

### The 6 Guided Training Tasks
1. **Task 1: Facility Map Exploration**
   - Click the top-right Facility Map widget (or press <kbd>M</kbd>).
   - Opens the NASA research complex directory and minimap radar.
2. **Task 2: Ground Station Familiarization**
   - Navigate to the Ground Station sector. Click the high-gain telemetry antenna or press <kbd>E</kbd>.
   - Learn about telemetry uplink/downlink, radio frequencies, and light-speed signal latency.
3. **Task 3: Spacecraft Assembly Architecture**
   - Navigate to the Spacecraft Assembly Hangar. Click the test spacecraft on the inspection pedestal.
   - Interactive Subsystems Explorer: Click and inspect all 4 core subsystems (*Bus Frame, Power/Solar Arrays, Avionics Guidance, and Propulsion Mount*).
4. **Task 4: Scientific Instruments**
   - Navigate to the Scientific Research Laboratory cleanroom.
   - Click an instrument crate (*Thermometer, Barometer, Camera*) to examine scientific data collection and mass/power/cost trade-offs.
5. **Task 5: Mission Control Center**
   - Navigate to Mission Control Center.
   - Click the central video wall to inspect live telemetry streams, flight trajectories, and mission debriefing protocols.
6. **Task 6: Resource Systems & Currency**
   - Identify Grant Credits (`₡`) and Star Credits (`★`) in the top status bar.
   - Understand payload mass, engine impulse, and budget limits.

### Training Completion
- **Header:** `CADET TRAINING COMPLETED!`
- **Text:** *"You've explored the facility, learned the essential systems, and are ready to design your first space mission."*
- **Action:** Click **VIEW MISSION LEVELS** to launch the campaign.

---

## 3. Level 1: Satellite Assembly Lab

**Location:** NASA Spacecraft Assembly Hangar (`SAH Cleanroom`)  
**Objective:** Assemble an Earth observation satellite with all 7 essential subsystems on the hangar assembly stand.

### Interactive 3D Assembly Workspace
- **Centre 3D Viewport:** Interactive 3D satellite model on an assembly pedestal. Click and drag to orbit 360° around the satellite.
- **Left Panel:** Tactical mission instructions, educational engineering feedback box, and subsystems checklist (`0/7` to `7/7`).
- **Right Panel:** Component selection panel with the 7 draggable / clickable satellite components.
- **Top Section:** Level badge, Star Credits balance, and animated progress bar (`0/7`).

### The 7 Satellite Subsystems
1. **Solar Panels:** Generate electrical power using photovoltaic gallium-arsenide cells.
2. **Battery:** Stores electrical energy in high-capacity Li-ion cells for orbital eclipse periods.
3. **Antenna:** High-gain steerable parabolic dish for S-band / X-band communication with NASA ground stations.
4. **Scientific Camera:** Nadir-pointing optical telescope for Earth surface observation and environmental imaging.
5. **Onboard Computer (OBC):** Radiation-hardened avionics flight computer executing flight software and telemetry monitoring.
6. **Attitude Control System (ADCS):** 3-axis reaction wheels and star trackers for gyroscopic orientation and camera pointing.
7. **Propulsion System:** Aft monopropellant rocket thrusters and propellant tanks for orbital delta-v maneuvers and station-keeping.

### Assembly Mechanics & Educational Feedback
- **Drag-and-Drop & Click-to-Mount:**
  - Drag components from the right panel onto the 3D satellite model's glowing target markers.
  - Or click any component card to select it, then click its corresponding holographic target badge.
- **Snapping & 3D Transformation:**
  - When correctly mounted, the 3D subsystem appears on the satellite model with a smooth scale-in animation, accompanied by a crisp audio confirmation chime (`SFX.snapCorrect()`).
  - The subsystems checklist updates, and the feedback box provides detailed engineering explanations of its function.
- **Contextual Error Handling:**
  - If a player attempts to mount a component in the wrong location, the card shakes, an error tone sounds (`SFX.snapWrong()`), and the feedback box explains *why* the placement is incorrect and where it should be mounted.
- **Completion & Rewards:**
  - Installing all 7 components triggers a celebratory orbital spin, triumphant fanfare (`SFX.levelComplete()`), and displays the **SATELLITE ASSEMBLY SUCCESSFUL!** award modal.
  - **Rewards:** **+100 Star Credits** and the **Satellite Builder Badge** (`SATELLITE_BUILDER` SVG).
  - Automatically unlocks Level 2 in the Mission Campaign.

---

## 4. Ten-Level Mission Campaign & Level Directory

Title: **SPACEVERSE – MISSION CAMPAIGN & LEVEL DIRECTORY**  
Accessible anytime via the **`🚀 Level Chart & Missions`** button on the Top Command Bar or by pressing <kbd>C</kbd>.

### Progression Roadmap
| Level | Mission Title | Target Altitude / Orbit | Budget | Required Payload / Hardware | Reward |
| :---: | :--- | :---: | :---: | :--- | :--- |
| **01** | Satellite Assembly Lab | Earth Observation Orbit | $60M Grant | 7 Core Satellite Subsystems | ★ 100 Star Credits + Satellite Builder Badge |
| **02** | Stratospheric Sky Imaging | 70 km (Stratosphere) | $80M | 🌡️ Thermometer, 📷 Multispectral Camera | ₡ 8,000 Grants + Score |
| **03** | Full Atmospheric Survey | 85 km (Mesosphere) | $100M | 🌡️ Thermometer, 📊 Barometer, 📷 Camera | ₡ 10,000 Grants + Score |
| **04** | Mesosphere Upper Boundary | 100 km (Kármán Threshold) | $110M | 🌡️ Thermometer, 📊 Barometer | ₡ 11,000 Grants + Cert |
| **05** | Kármán Line Crossing | 125 km (Official Space) | $125M | 📊 Barometer, 📷 Horizon Camera | ₡ 12,500 Grants + Honors |
| **06** | Thermosphere Telemetry Probe | 150 km (Thermosphere) | $140M | 🌡️ Thermometer, 📊 Barometer, 📷 Camera | ₡ 14,000 Grants + Clearance |
| **07** | Ionospheric Sounding Array | 180 km (Ionosphere) | $165M | 🌡️ Thermometer, 📊 Barometer | ₡ 16,500 Grants + Accolades |
| **08** | Orbital Velocity Staging | 220 km (Low Earth Orbit) | $190M | 🌡️ Thermometer, 📷 Optical Payload | ₡ 19,000 Grants + Specialist |
| **09** | Deep Orbit Weather Observatory | 260 km (Deep LEO) | $220M | 🌡️ Thermometer, 📊 Barometer, 📷 Camera | ₡ 22,000 Grants + Commendation |
| **10** | Lunar Trajectory Test Vehicle | 300+ km (Trans-Lunar) | $250M | 🌡️ Thermometer, 📊 Barometer, 📷 Camera | ₡ 25,000 Grants + Master Architect |

- **Card States:**
  - **Completed:** Marked in gold with stars (`★`) and personal best flight score.
  - **Available:** Glowing cyan border with **`LAUNCH MISSION ▶`** / **`LAUNCH SATELLITE LAB ▶`** button.
  - **Locked:** Dimmed with lock icon (`🔒`), unlocked sequentially upon completing the previous level.

---

## 5. UI Architecture: Unified Aerospace Command Bar

The interface has been redesigned to eliminate scattered floating boxes:
- **Aerospace Command Bar (Top):**
  - Brand identity: `SPACEVERSE // GALAXY-X`
  - Quick-navigation pills: `[🚀 Level Chart & Missions]`, `[🎓 Cadet Training]`, `[🗺️ Facility Map]`
  - Currency counters: `₡ Grant Credits` and `★ Star Credits`
  - Dossier / Profile launcher button
  - Global Sound Effects Mute / Unmute button (`🔊` / `🔇`)
- **Tactical Objective HUD Widget (`#obj`):**
  - Styled as an aeronautical heads-up display.
  - Contains directive title, target altitude, budget meter, and required hardware pills.
  - Automatically hidden during Cadet Training and Satellite Assembly Lab.
- **Rocket Manifest Console (`#man`):**
  - High-tech vehicle telemetry gauge with mass meters and budget bars.
  - Automatically hidden during exploration and training; dynamically appears only when staging in Assembly Hangar, Research Lab, or Launch Control.
- **Interaction Prompt (`#pr`):**
  - Centered floating action badge (`[ E ] PRESS TO INTERACT`).

---

## 6. Sound Effects & Global Audio Engine

Built using a lightweight Web Audio API synthesizer for clean, futuristic electronic feedback:
- **Button Clicks:** Short electronic beep (`SFX.click()`).
- **Object Selection:** Soft digital chirp (`SFX.select()`).
- **Correct Placement:** Satisfying multi-tone snap chime (`SFX.snapCorrect()`).
- **Incorrect Placement:** Low electronic buzzer (`SFX.snapWrong()`).
- **Task Completion:** Positive 3-tone chime (`SFX.taskComplete()`).
- **Level Completion:** Triumphant 4-note ascending fanfare (`SFX.levelComplete()`).
- **Badge Unlocked:** Celebratory high-register arpeggio (`SFX.badgeUnlock()`).
- **Facility Navigation:** Futuristic spatial whoosh when fast-traveling (`SFX.navigate()`).
- **Global Mute Button:** Fixed on the Top Command Bar with speaker icon (`🔊` / `🔇`). State is persisted in `localStorage`.

---

## 7. Controls & Navigation

- **Move:** <kbd>W</kbd>, <kbd>A</kbd>, <kbd>S</kbd>, <kbd>D</kbd> or on-screen touch joystick.
- **Look:** Click and drag the viewport.
- **Interact:** Click directly on 3D objects (raycasting) or press <kbd>E</kbd> / touch **Act** button.
- **Facility Map:** Click **Facility Map** button or press <kbd>M</kbd>.
- **Level Chart:** Click **Level Chart & Missions** button or press <kbd>C</kbd>.
- **Cadet Training:** Click **Cadet Training** button on the Top Command Bar.
- **Profile / Dossier:** Click **Dossier** on the Top Command Bar.
