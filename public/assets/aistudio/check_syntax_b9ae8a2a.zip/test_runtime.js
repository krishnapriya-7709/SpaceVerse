// Mock browser environment and Three.js
const fs = require('fs');

const mockCtx = {
   fillStyle: '',
   strokeStyle: '',
   lineWidth: 1,
   fillRect: () => { },
   strokeRect: () => { },
   beginPath: () => { },
   moveTo: () => { },
   lineTo: () => { },
   stroke: () => { },
   fill: () => { },
   arc: () => { },
   fillText: () => { }
};

const elements = {};
function getOrCreateEl(id) {
   if (!elements[id]) {
      elements[id] = {
         id,
         style: {},
         classList: {
            add: (c) => { },
            remove: (c) => { },
            contains: (c) => false
         },
         dataset: {},
         appendChild: (child) => { },
         insertBefore: () => { },
         addEventListener: (ev, fn) => { },
         getContext: () => mockCtx,
         getBoundingClientRect: () => ({ width: 800, height: 600, top: 0, left: 0 })
      };
   }
   return elements[id];
}

global.document = {
   getElementById: (id) => getOrCreateEl(id),
   querySelectorAll: () => [],
   querySelector: () => null,
   createTextNode: (txt) => ({ textContent: txt }),
   addEventListener: () => { },
   createElement: (tag) => ({
      tagName: tag,
      style: {},
      classList: { add: () => { }, remove: () => { } },
      appendChild: () => { },
      insertBefore: () => { },
      addEventListener: () => { },
      dataset: {},
      getContext: () => mockCtx
   }),
   body: {
      prepend: () => { },
      appendChild: () => { }
   }
};
global.window = {
   devicePixelRatio: 1,
   innerWidth: 1920,
   innerHeight: 1080,
   addEventListener: () => { },
   requestAnimationFrame: (cb) => { }
};
global.addEventListener = global.window.addEventListener;
global.requestAnimationFrame = global.window.requestAnimationFrame;
global.MutationObserver = class {
   constructor(cb) { }
   observe() { }
   disconnect() { }
};
global.localStorage = {
   getItem: () => null,
   setItem: () => { }
};

// Mock Three.js
class Color {
   constructor(c) { this.hex = c; }
   setHex(h) { this.hex = h; return this; }
}
class Vector2 { constructor(x = 0, y = 0) { this.x = x; this.y = y; } }
class Vector3 {
   constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; this.isVector3 = true; }
   set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
   applyEuler() { return this; }
   add() { return this; }
   project() { return this; }
}
class Group {
   constructor() { this.children = []; this.position = new Vector3(); this.rotation = { x: 0, y: 0, z: 0, set: function (x, y, z) { this.x = x; this.y = y; this.z = z; } }; this.scale = new Vector3(1, 1, 1); }
   add(obj) { this.children.push(obj); }
}
class Scene extends Group { }
class Material {
   constructor(params = {}) {
      this.color = new Color(params.color || 0xffffff);
      this.roughness = params.roughness || 0.5;
      this.metalness = params.metalness || 0.5;
      this.emissive = new Color(params.emissive || 0x000000);
   }
}
class Mesh {
   constructor(geo, mat) {
      this.geometry = geo;
      this.material = mat || new Material();
      this.position = new Vector3();
      this.rotation = { x: 0, y: 0, z: 0, set: function (x, y, z) { this.x = x; this.y = y; this.z = z; } };
      this.scale = new Vector3(1, 1, 1);
   }
}
class WebGLRenderer {
   constructor() {
      this.domElement = {
         className: '',
         style: {},
         addEventListener: () => { },
         setPointerCapture: () => { },
         releasePointerCapture: () => { }
      };
   }
   setPixelRatio() { }
   setSize() { }
   render(scene, camera) {
      function traverse(obj) {
         if (!obj.position || typeof obj.position.set !== 'function') {
            console.warn('WARNING: obj.position is NOT a Vector3! obj:', obj);
         }
         if (obj.children) obj.children.forEach(traverse);
      }
      traverse(scene);
   }
}

global.THREE = {
   Scene, Group, Mesh, Vector2, Vector3, Color,
   PerspectiveCamera: class {
      constructor(fov, aspect, near, far) {
         this.position = new Vector3();
         this.rotation = { x: 0, y: 0, z: 0, order: 'XYZ', set: function (x, y, z) { this.x = x; this.y = y; this.z = z; } };
      }
      lookAt() { }
      updateProjectionMatrix() { }
   },
   WebGLRenderer,
   Raycaster: class { constructor() { } setFromCamera() { } intersectObjects() { return []; } },
   AmbientLight: class { constructor() { this.position = new Vector3(); } },
   DirectionalLight: class { constructor() { this.position = new Vector3(); } },
   PointLight: class { constructor() { this.position = new Vector3(); } },
   SpotLight: class { constructor() { this.position = new Vector3(); this.target = { position: new Vector3() }; } },
   FogExp2: class { constructor(c, d) { } },
   CylinderGeometry: class { },
   TorusGeometry: class { },
   BoxGeometry: class { },
   SphereGeometry: class { },
   ConeGeometry: class { },
   PlaneGeometry: class { },
   RingGeometry: class { },
   BufferGeometry: class { setAttribute() { } },
   BufferAttribute: class { },
   MeshStandardMaterial: Material,
   MeshLambertMaterial: Material,
   MeshBasicMaterial: Material,
   MeshPhongMaterial: Material,
   PointsMaterial: class { },
   Points: class { constructor() { this.position = new Vector3(); } },
   SpriteMaterial: class { },
   Sprite: class { constructor() { this.position = new Vector3(); this.scale = new Vector3(1, 1, 1); } },
   CanvasTexture: class { constructor() { this.wrapS = 0; this.wrapT = 0; this.repeat = { set: () => { } }; } },
   RepeatWrapping: 1000,
   DoubleSide: 2
};

const code = fs.readFileSync('Mission Architect_ Space Base.html', 'utf8');
const scriptMatch = code.match(/<script\b[^>]*>([\s\S]*?)<\/script>/gi);
const scriptContent = scriptMatch[1].replace(/^<script\b[^>]*>/i, '').replace(/<\/script>$/i, '');

// Expose exports
let contextFn = new Function(`
var SFX;
${scriptContent}
return {
   startSatelliteAssemblyLab,
   initSatLab3D,
   renderSatWorkspace,
   satParts,
   SAT_COMPONENTS,
   satInstalledParts,
   installSatComponent,
   SFX: window.SFX,
   satLabLoop,
   satLabRenderer,
   satLabScene,
   satLabCamera
};
`);

try {
   const exports = contextFn();
   console.log('Script loaded successfully!');
   console.log('Testing startSatelliteAssemblyLab()...');
   exports.startSatelliteAssemblyLab();
   console.log('startSatelliteAssemblyLab() succeeded!');
   console.log('Components count:', exports.SAT_COMPONENTS.length);
   console.log('Installed parts size:', exports.satInstalledParts.size);
   console.log('Testing satLabLoop()...');
   exports.satLabLoop();
   console.log('Testing installSatComponent(camera)...');
   exports.installSatComponent('camera');
   console.log('Installed parts after camera:', exports.satInstalledParts.size);
   setTimeout(() => process.exit(0), 500);
} catch (e) {
   console.error('Execution Error:', e);
   process.exit(1);
}
